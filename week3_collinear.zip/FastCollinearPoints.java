import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.In;

import java.util.Arrays;
import java.util.ArrayList;

public class FastCollinearPoints {
    private ArrayList<LineSegment> jSegments = new ArrayList<>();

    public FastCollinearPoints(Point[] points){
        if(points == null){throw new IllegalArgumentException("points can't be null");}
        for(int p=0; p<points.length; p++){
            if (points[p] == null) throw new IllegalArgumentException("points can't be null");
        }

        for(int p=1; p<points.length; p++){
            for(int j=p+1; j< points.length; j++){
                if (points[p].compareTo(points[j]) == 0) throw new IllegalArgumentException("points can't be duplicate");
            }
        }

        Point[] sort_points = Arrays.copyOf(points, points.length);
        Arrays.sort(sort_points);


        for(int i=0; i<points.length-3; i++){
            Arrays.sort(sort_points);
            Arrays.sort(sort_points, sort_points[i].slopeOrder());

            for (int p = 0, first = 1, last = 2; last < sort_points.length; last++) {
                // find last collinear to p point
                while (last < sort_points.length
                        && Double.compare(sort_points[p].slopeTo(sort_points[first]), sort_points[p].slopeTo(sort_points[last])) == 0) {
                    last++;
                }
                // if found at least 3 elements, make segment if it's unique
                if (last - first >= 3 && sort_points[p].compareTo(sort_points[first]) < 0) {
                    jSegments.add(new LineSegment(sort_points[p], sort_points[last - 1]));
                }
                // Try to find next
                first = last;
            }
        }

    }

    private LineSegment chooseEnd(Point[] segPoints){
        Point min_point = segPoints[0];
        Point max_point = segPoints[0];
        for(int p=1; p<segPoints.length; p++){
            if(segPoints[p].compareTo(min_point) < 0) {min_point = segPoints[p];}
            if(segPoints[p].compareTo(max_point) > 0) {max_point = segPoints[p];}
        }
        return new LineSegment(min_point, max_point);
    }

    public int numberOfSegments(){
        return jSegments.size();
    }

    public LineSegment[] segments(){
        return jSegments.toArray(new LineSegment[jSegments.size()]);
    }

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
