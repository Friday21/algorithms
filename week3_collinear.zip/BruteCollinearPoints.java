import java.util.Comparator;
import java.lang.IllegalArgumentException;

public class BruteCollinearPoints {
    private int segNum = 0;
    private LineSegment[] lines;
    public BruteCollinearPoints(Point[] points){
        if(points == null){throw new IllegalArgumentException("points can't be null");}
        for(int p=0; p<points.length; p++){
            if (points[p] == null) throw new IllegalArgumentException("points can't be null");
        }
        for(int p=0; p<points.length; p++){
            for(int j=p+1; j< points.length; j++){
                if (points[p].compareTo(points[j]) == 0) throw new IllegalArgumentException("points can't be duplicate");
            }
        }

        lines = new LineSegment[points.length];
        for(int i=0; i<points.length-3; i++){
            Comparator<Point> cmp = points[i].slopeOrder();
            for(int j=i+1; j < points.length-2; j++){
                for(int m=j+1; m<points.length-1; m++){
                    if (cmp.compare(points[j], points[m])==0){
                        for(int n=m+1; n<points.length; n++){
                            if (cmp.compare(points[n], points[m])==0) {
                                lines[segNum++] = chooseEnd(points[i], points[j], points[m], points[n]);
                            }
                        }
                    }
                }
            }
        }
    }

    public int numberOfSegments(){
        return segNum;
    }

    private LineSegment chooseEnd(Point p1, Point p2, Point p3, Point p4){
        Point min_point = p1;
        Point max_point = p1;
        if(p2.compareTo(min_point) < 0) {min_point = p2;}
        if(p2.compareTo(max_point) > 0) {max_point = p2;}
        if(p3.compareTo(min_point) < 0) {min_point = p3;}
        if(p3.compareTo(max_point) > 0) {max_point = p3;}
        if(p4.compareTo(min_point) < 0) {min_point = p4;}
        if(p4.compareTo(max_point) > 0) {max_point = p4;}
        return new LineSegment(min_point, max_point);
    }

    public LineSegment[] segments(){
        LineSegment[] seg_lines = new LineSegment[segNum];
        for(int i=0; i<segNum; i++){seg_lines[i]=lines[i];}
        return seg_lines;
    }
}
