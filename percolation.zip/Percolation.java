import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;


public class Percolation {
    private WeightedQuickUnionUF union_find;
    private int[] site;
    private int num;
    private int open_num;

    public Percolation(int n) {
        union_find = new WeightedQuickUnionUF(n*n +2);
        num = n;
        open_num = 0;
        site = new int[n*n + 2];
        for (int i=0; i<n*n+2; i++) site[i] = 0;
        for (int i=1; i<n+1; i++){
            union_find.union(0, i);
            union_find.union(n*n+1, n*n+1-i);
        }
    }

    public void open(int row, int col) {
        if (isOpen(row, col)) return ;
        open_num++;
        int index = calIndex(row, col);
        site[index] = 1;
        if (row > 1 && isOpen(row-1, col)){
            int index_up = calIndex(row-1, col);
            union_find.union(index, index_up);
        }

        if (row+1 <= num && isOpen(row+1, col)){
            int index_down = calIndex(row+1, col);
            union_find.union(index, index_down);
        }

        if (col > 1 && isOpen(row, col-1)){
            int index_left = calIndex(row, col-1);
            union_find.union(index, index_left);
        }

        if (col + 1 <= num && isOpen(row, col+1)){
            int index_right = calIndex(row, col+1);
            union_find.union(index, index_right);
        }
    }

    public boolean isOpen(int row, int col) {
        int index = calIndex(row, col);
        return site[index] == 1;
    }

    public boolean isFull(int row, int col) {
        int index = calIndex(row, col);
        return site[index] == 0;
    }

    public int numberOfOpenSites() {
        return open_num;
    }

    public boolean isPercolate(){
        return union_find.connected(0, num*num + 1);
    }

    private int calIndex(int row, int col){
        return num * (row - 1) + col;
    }

    public void randomOpenUntilPercolate(){
        while (!isPercolate()){
            int row = StdRandom.uniform(1, num+1);
            int col = StdRandom.uniform(1, num+1);
            open(row, col);
        }
    }

    public static void main(String[] args){
        int n = StdIn.readInt();
        Percolation percolation = new Percolation(n);
        percolation.randomOpenUntilPercolate();
    }

}