import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdStats;


public class PercolationStats {
    private int trails;
    private double[] probability;


    public PercolationStats(int n, int trials){
        trails = trials;
        probability = new double[trials];
        for (int i=0; i<trials; i++){
            StdOut.print(i);
            Percolation percolation = new Percolation(n);
            percolation.randomOpenUntilPercolate();
            probability[i] = (double)percolation.numberOfOpenSites()/(double)(n*n);
        }
    }

    public double mean() {
        return StdStats.mean(probability);
    }

    public double stddev(){
        return StdStats.stddev(probability);
    }

    public double confidenceLo(){
        return mean() - 1.96*stddev()/java.lang.Math.sqrt(trails);
    }

    public double confidenceHi(){
        return mean() + 1.96*stddev()/java.lang.Math.sqrt(trails);
    }

    public static void main(String[] args){
        int n = StdIn.readInt();
        int trails = StdIn.readInt();
        PercolationStats per_stats = new PercolationStats(n, trails);
        StdOut.printf("mean = %f\n", per_stats.mean());
        StdOut.printf("stddev = %f\n", per_stats.stddev());
        StdOut.printf("95%% confidence interval = [%f, %f]\n",
                per_stats.confidenceLo(), per_stats.confidenceHi());
    }
}
