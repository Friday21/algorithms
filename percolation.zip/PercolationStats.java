import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;


public class PercolationStats {
    private int trails;
    private double[] probability;
    private double mean_prob;
    private double stddev_prob;


    public PercolationStats(int n, int trials){
        if (n<= 0) {
            throw  new java.lang.IllegalArgumentException("n should bigger than 0");
        }
        if (trials<= 0) {
            throw  new java.lang.IllegalArgumentException("trials should bigger than 0");
        }
        trails = trials;
        probability = new double[trials];
        for (int i=0; i<trials; i++){
            Percolation percolation = new Percolation(n);
            while (!percolation.percolates()){
                int row = StdRandom.uniform(1, n+1);
                int col = StdRandom.uniform(1, n+1);
                percolation.open(row, col);
            }
            probability[i] = (double)percolation.numberOfOpenSites()/(double)(n*n);
        }
    }

    public double mean() {
        mean_prob = StdStats.mean(probability);
        return mean_prob;
    }

    public double stddev(){
        stddev_prob = StdStats.stddev(probability);
        return stddev_prob;
    }

    public double confidenceLo(){
        if (mean_prob == 0) mean();
        if (stddev_prob == 0) stddev();
        return mean_prob - 1.96*stddev_prob/java.lang.Math.sqrt(trails);
    }

    public double confidenceHi(){
        if (mean_prob == 0) mean();
        if (stddev_prob == 0) stddev();
        return mean_prob + 1.96*stddev_prob/java.lang.Math.sqrt(trails);
    }

    public static void main(String[] args){
        int n = StdIn.readInt();
        int trails = StdIn.readInt();
        PercolationStats per_stats = new PercolationStats(n, trails);
        StdOut.printf("mean = %f\n", per_stats.mean());
        StdOut.printf("stddev = %f\n", per_stats.stddev());
        StdOut.printf("95%% confidence interval = [%f, %f]\n",
                per_stats.confidenceLo(), per_stats.confidenceHi());
    }
}
