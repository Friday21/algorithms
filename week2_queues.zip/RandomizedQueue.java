import java.util.Iterator;
import edu.princeton.cs.algs4.StdRandom;
import java.lang.IllegalArgumentException;
import java.util.NoSuchElementException;
import java.lang.UnsupportedOperationException;
import edu.princeton.cs.algs4.StdOut;

public class RandomizedQueue <Item> implements Iterable<Item> {
    private Item[] queue;
    private int head;
    private int tail;

    public RandomizedQueue(){
        head = 0;
        tail = 0;
        queue = (Item[]) new Object[1];
    }

    public boolean isEmpty(){return head == tail;}

    public int size(){return tail - head;}

    public void enqueue(Item item){
        if (item==null){throw new IllegalArgumentException("item can't be null");}
        if (tail-head == queue.length) resize(2 * queue.length);
        queue[tail++] = item;
    }

    public Item dequeue(){
        if (isEmpty()){throw new NoSuchElementException("empty");}
        int choice = StdRandom.uniform(head, tail);
        Item item = queue[choice];
        queue[choice] = queue[--tail];
        queue[tail] = null;
        return item;
    }

    public Item sample(){
        if (isEmpty()){throw new NoSuchElementException("empty");}
        int choice = StdRandom.uniform(head, tail);
        Item item = queue[choice];
        return item;
    }

    private void resize(int capacity){
        Item[] copy = (Item[]) new Object[capacity];
        for (int i = 0; i < tail-head; i++)
            copy[i] = queue[head+i];
        queue = copy;
    }

    public Iterator<Item> iterator(){
        return new RandomizedQueueIterator();
    }

    private class RandomizedQueueIterator implements Iterator<Item> {

        private int iter_head;
        private int iter_tail;
        private Item [] iter_queue;

        public RandomizedQueueIterator(){
            iter_head = 0;
            iter_tail = tail-head;
            iter_queue = (Item[]) new Object[iter_tail];
            for(int i=0; i<iter_tail; i++){
                iter_queue[i] = queue[head+i];
            }
        }

        public boolean hasNext() {
            return iter_head != iter_tail;
        }

        public Item next(){
            if (iter_head==iter_tail){throw new NoSuchElementException("empty");}
            int choice = StdRandom.uniform(iter_head, iter_tail);
            Item item = iter_queue[choice];
            iter_queue[choice] = iter_queue[--iter_tail];
            iter_queue[iter_tail] = null;
            return item;
        }

        public void remove(){throw new UnsupportedOperationException("not supported");}
    }

    public static void main(String[] args){
        RandomizedQueue<Integer> q = new RandomizedQueue<Integer>();
        q.enqueue(1);
        q.enqueue(2);
        q.enqueue(3);
        q.enqueue(4);
        q.enqueue(5);

        StdOut.printf("deque: %d\n", q.dequeue());
//        Iterator iter = q.iterator();
//        while(iter.hasNext()){
//            StdOut.printf("%d\n", iter.next());
//        }
    }
}
