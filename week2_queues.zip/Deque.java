import java.util.Iterator;
import java.lang.IllegalArgumentException;
import java.util.NoSuchElementException;
import java.lang.UnsupportedOperationException;
//import edu.princeton.cs.algs4.StdOut;


public class Deque <Item> implements Iterable<Item> {
    private Node first;
    private Node last;
    private int N;

    public Deque(){
        N = 0;
    }

    private class Node
    {
        Item item;
        Node next;
        Node prev;
    }

    public boolean isEmpty(){
        return N==0;
    }

    public int size() {
        return N;
    }

    public void addFirst(Item item) {
        if (item == null){
            throw new IllegalArgumentException("item can't be null");
        }
        Node oldFirst = first;
        first = new Node();
        first.next = oldFirst;
        first.item = item;
        if (isEmpty()) {
            last = first;
        } else{
            oldFirst.prev = first;
        }
        N++;
    }

    public void addLast(Item item) {
        if (item == null){
            throw new IllegalArgumentException("item can't be null");
        }
        Node oldLast = last;
        last = new Node();
        last.prev = oldLast;
        last.item = item;
        if (isEmpty()){
            first = last;
        }else{
            oldLast.next = last;
        }
        N++;
    }

    public Item removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException("empty deque");
        }
        N--;
        Item item = first.item;
        if (isEmpty()) {
            first = null;
            last = null;
            return item;
        } else {
            first = first.next;
            first.prev = null;
            return item;
        }
    }

    public Item removeLast() {
        if (isEmpty()){
            throw new NoSuchElementException("empty deque");
        }
        N--;
        Item item = last.item;
        if (isEmpty()){
            first=null;
            last=null;
            return item;
        }else{
            Node oldLast = last;
            last = last.prev;
            last.next = null;
            oldLast = null;
            return item;
        }
    }

    public Iterator<Item> iterator(){
        return new DequeIterator();
    }

    private class DequeIterator implements Iterator<Item> {
        private Node current = first;

        public boolean hasNext() {
            return current != null;
        }

        public Item next(){
            if (current == null) throw new NoSuchElementException("empty deque");
            Item item = current.item;
            current = current.next;
            return item;
        }

        public void remove(){
            throw new UnsupportedOperationException("not supported");
        }
    }

    public static void main(String[] args){
        Deque<Integer> deque = new Deque<Integer>();
        deque.addFirst(1);
        deque.addFirst(2);
        deque.addLast(3);
        deque.addLast(4);
        deque.removeFirst();
        deque.removeLast();
//        Iterator iter = deque.iterator();
//        while(iter.hasNext()){
//            StdOut.printf("%d\n", iter.next());
//        }
    }
}
